<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Grupos de <?php echo e($planEstudio->carrera); ?></p>
        
        <div class="buttons">
            <a href="<?php echo e(route('escolaresPlanesEstudio')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-grupo">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Grupo
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>Letra Grupo</th>
                    <th>Periodo</th>
                    <th>Materia</th>
                    <th>Semestre</th>
                    <th>Docente</th>
                    <th>Capacidad</th>
                    <th class="has-text-centered">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $planEstudio->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($grupo->letra_grupo); ?></td>
                        <td><?php echo e($grupo->periodo->nombre_periodo); ?></td>
                        <td><?php echo e($grupo->materia->nombre); ?></td>
                        <td><?php echo e($grupo->semestre); ?></td>
                        <td><?php echo e($grupo->docente->ap_paterno.' '.
                                $grupo->docente->ap_materno.' '.
                                $grupo->docente->nombre); ?>

                        </td>
                        <td><?php echo e($grupo->capacidad); ?></td>
                        <td> 
                            <div class="field is-grouped has-text-centered">
                                <button class="button is-warning js-modal-trigger" data-target="modal-update-<?php echo e($grupo->id); ?>">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                
                                <form action="<?php echo e(route('grupoDelete', [$planEstudio->id, $grupo->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar la materia?')">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

                    <div id="modal-update-<?php echo e($grupo->id); ?>" class="modal">
                        <div class="modal-background"></div>
                        <div class="modal-content">
                            <div class="box">
                                <p class="title is-5 has-text-centered">Modificar Grupo</p>
                                <form method="POST" action="<?php echo e(route('grupoUpdate', [$planEstudio->id, $grupo->id] )); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="field">
                                        <label class="label">Letra de grupo:</label>
                                        <div class="control">
                                            <input class="input" type="text" name="txtLetraGrupoUp"
                                                value="<?php echo e($grupo->letra_grupo); ?>">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Periodo:</label>
                                        <div class="control">
                                            <div class="select">
                                                <select name="selectPeriGrupoUp">
                                                    <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($periodo->estatus != 'cerrado'): ?>
                                                            <option value="<?php echo e($periodo->id); ?>">
                                                                <?php echo e($periodo->nombre_periodo); ?>

                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>                
                                        </div>
                                    </div>
                                    
                                    <div class="field">
                                        <label class="label">Materia:</label>
                                        <div class="control">
                                            <div class="select">
                                                <select name="selectMatGrupUp">
                                                    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($materia->id); ?>">
                                                            <?php echo e($materia->nombre); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>                
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Semestre:</label>
                                        <div class="control">
                                            <input class="input" type="number" name="txtSemGrupoUp"
                                            value="<?php echo e($grupo->semestre); ?>">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Docente:</label>
                                        <div class="control">
                                            <div class="select">
                                                <select name="selectDocenGrupUp">
                                                    <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($docente->id); ?>">
                                                            <?php echo e($docente->ap_paterno); ?> <?php echo e($docente->ap_materno); ?> <?php echo e($docente->nombre); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>                
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Capacidad:</label>
                                        <div class="control">
                                            <input class="input" type="number" name="txtCapGrupoUp"
                                            value="<?php echo e($grupo->capacidad); ?>">
                                        </div>
                                    </div>
                                    <div class="has-text-centered">
                                        <button class="button is-primary" type="submit">Guardar</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <button class="modal-close is-large" aria-label="close"></button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!--Modal para crear alumnos -->
        <div id="modal-nvo-grupo" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar Grupo</p>
                    <form method="POST" action="<?php echo e(route('grupoCreate', $planEstudio->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <label class="label">Letra de grupo:</label>
                            <div class="control has-icons-left">
                                <input class="input" type="text" name = "txtLetraGrupo" 
                                    value="<?php echo e(old('txtLetraGrupo')); ?>">
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-key"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['txtLetraGrupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la letra del grupo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <label class="label">Periodo:</label>
                            <div class="control has-icons-left">
                                <div class="select">
                                    <select name="selectPeriGrupo">
                                        <option value="">Seleccionar</option>
                                        <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($periodo->estatus != 'Cerrado'): ?>
                                                <option value="<?php echo e($periodo->id); ?>">
                                                    <?php echo e($periodo->nombre_periodo); ?>

                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>                
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-graduation-cap"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['selectPeriGrupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el periodo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <div class="field">
                            <label class="label">Materia:</label>
                            <div class="control has-icons-left">
                                <div class="select">
                                    <select name="selectMatGrup">
                                        <option value="">Seleccionar</option>
                                        <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($materia->id); ?>">
                                                <?php echo e($materia->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>                
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-graduation-cap"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['selectMatGrup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la materia del grupo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <label class="label">Semestre:</label>
                            <div class="control has-icons-left">
                                <input class="input" type="number" name = "txtSemGrupo" 
                                    value="<?php echo e(old('txtSemGrupo')); ?>">
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-key"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['txtSemGrupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el semestre de grupo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <div class="field">
                            <label class="label">Docente:</label>
                            <div class="control has-icons-left">
                                <div class="select">
                                    <select name="selectDocenGrup">
                                        <option value="">Seleccionar</option>
                                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($docente->id); ?>">
                                                <?php echo e($docente->ap_paterno); ?> <?php echo e($docente->ap_materno); ?> <?php echo e($docente->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>                
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-graduation-cap"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['selectDocenGrup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el docente del grupo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <div class="field">
                            <label class="label">Capacidad:</label>
                            <div class="control has-icons-left">
                                <input class="input" type="number" name = "txtCapGrupo" 
                                    value="<?php echo e(old('txtCapGrupo')); ?>">
                                <span class="icon is-small is-left">
                                    <i class="fa-solid fa-key"></i>
                                </span>
                            </div>
                            <?php $__errorArgs = ['txtCapGrupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la capacidad del grupo</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
            <button class="modal-close is-large" aria-label="close"></button>
        </div>



    </div>

    <?php if($errors->has('txtClave') || $errors->has('txtCarrera') ): ?>
        <script>
            document.getElementById('modal-nvo-plan').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/escolares/grupo.blade.php ENDPATH**/ ?>