<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Gestion de Alumnos</p>
        <p class="title is-5 has-text-centered">
            <?php echo e($grupos->materia->nombre.' - Grupo: '.
                $grupos->letra_grupo.' - '.
                $grupos->docente->ap_paterno.' '.
                $grupos->docente->ap_materno.' '.
                $grupos->docente->nombre); ?>

        </p>
        
        <div class="buttons">
            <a href="#" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>No. Control</th>
                    <th>Nombre Completo</th>
                    <th>Semestre</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $grupos->alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alumno->id); ?></td>
                        <td><?php echo e($alumno->ap_paterno. ' '.$alumno->ap_materno.' '. $alumno->nombre); ?></td>
                        <td><?php echo e($alumno->semestre); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/docente/lista-alumno-docente.blade.php ENDPATH**/ ?>