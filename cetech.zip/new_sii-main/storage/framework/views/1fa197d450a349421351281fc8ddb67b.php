<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Docentes</p>
        
        <div class="buttons">
            <a href="<?php echo e(route('home')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-plan">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Docente
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>RFC</th>
                    <th>Nombre Completo</th>
                    <th>CURP</th>
                    <th>Email</th>
                    <th class="has-text-centered">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->rfc); ?></td>
                        <td><?php echo e($item->ap_paterno . ' ' . $item->ap_materno . ' ' . $item->nombre); ?></td>
                        <td><?php echo e($item->curp); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td>
                            <div class="field is-grouped">
                                <button class="button is-warning js-modal-trigger" data-target="modal-<?php echo e($item->id); ?>">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                <form action="<?php echo e(route('docenteDelete', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar al docente?')">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>

                            <div id="modal-<?php echo e($item->id); ?>" class="modal">
                                <div class="modal-background"></div>

                                <div class="modal-content">
                                    <div class="box">
                                        <p class="title is-5 has-text-centered">Modificar Plan de Estudio</p>
                                        <form method="POST" action="<?php echo e(route('docenteUpdate', $item->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="field">
                                                <label class="label">RFC:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtRFC"
                                                        value="<?php echo e($item->rfc); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Nombre:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtNombre"
                                                    value="<?php echo e($item->nombre); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Apellido Paterno:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtApPaterno"
                                                    value="<?php echo e($item->ap_paterno); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Apellido Materno:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtApMaterno"
                                                    value="<?php echo e($item->ap_materno); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">CURP:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtCURP"
                                                    value="<?php echo e($item->curp); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Email:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtEmail"
                                                    value="<?php echo e($item->email); ?>">
                                                </div>
                                            </div>
                                            <div class="has-text-centered">
                                                <button class="button is-primary" type="submit">Guardar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <button class="modal-close is-large" aria-label="close"></button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!--Modal para crear un nuevo plan -->
        <div id="modal-nvo-plan" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar Docente</p>
                    <form method="POST" action="<?php echo e(route('docenteCreate')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">RFC:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtRFC" value="<?php echo e(old('txtRFC')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-key"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtRFC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el RFC</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Nombre:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtNombre"
                                        value="<?php echo e(old('txtNombre')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtNombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el nombre del docente</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Apellido Paterno:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtApPaterno"
                                        value="<?php echo e(old('txtApPaterno')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtApPaterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el apellido del docente</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Apellido Materno:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtApMaterno"
                                        value="<?php echo e(old('txtApMaterno')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtApMaterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el apellido del docente</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">CURP:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtCURP"
                                        value="<?php echo e(old('txtCURP')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtCURP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el CURP del docente</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Email:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="email" name = "txtEmail"
                                        value="<?php echo e(old('txtEmail')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el correo electrónico del docente</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
        
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
        
            <button class="modal-close is-large" aria-label="close"></button>
        </div>



    </div>

    <?php if($errors->has('txtClave') || $errors->has('txtCarrera') ): ?>
        <script>
            document.getElementById('modal-nvo-plan').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/escolares/docente.blade.php ENDPATH**/ ?>