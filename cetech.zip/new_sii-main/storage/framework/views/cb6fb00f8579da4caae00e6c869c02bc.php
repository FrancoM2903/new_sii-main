<?php $__env->startSection('content'); ?>
    <div class="block">
        <p class="title is-3 has-text-centered">Edificios y Salones</p>
        
        <div class="buttons">
            <a href="<?php echo e(route('home')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-edificio">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Edificio
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-salon">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Salon
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="columns">
        
        <div class="column">
            <div class="box">
                <table class="table is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Edificio</th>
                            <th>Descripción</th>
                            <th class="has-text-centered">Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $edificios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->nombre_edificio); ?></td>
                            <td><?php echo e($item->descripcion); ?></td>
                            <td>
                                <div class="field is-grouped has-text-is-centered">
                                    <button class="button is-warning js-modal-trigger" data-target="modal-edificio-<?php echo e($item->id); ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <form action="<?php echo e(route('edificioDelete', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="button is-danger" <?php echo e($item->salones->count() > 0 ? 'disabled':''); ?> onclick="return confirm('¿Estás seguro de que quieres eliminar el edificio?')">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
    
                                <div id="modal-edificio-<?php echo e($item->id); ?>" class="modal">
                                    <div class="modal-background"></div>
    
                                    <div class="modal-content">
                                        <div class="box">
                                            <p class="title is-5 has-text-centered">Modificar Edificio</p>
                                            <form method="POST" action="<?php echo e(route('edificioUpdate', $item->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <div class="field">
                                                    <label class="label">Edificio:</label>
                                                    <div class="control">
                                                        <input class="input" type="text" name="txtEdificio"
                                                            value="<?php echo e($item->nombre_edificio); ?>">
                                                    </div>
                                                </div>
                                                <div class="field">
                                                    <label class="label">Descripción:</label>
                                                    <div class="control">
                                                        <input class="input" type="text" name="txtDescripcion"
                                                        value="<?php echo e($item->descripcion); ?>">
                                                    </div>
                                                </div>
                                                <div class="has-text-centered">
                                                    <button class="button is-primary" type="submit">Guardar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
    
                                    <button class="modal-close is-large" aria-label="close"></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody> 
                </table>
        
                <!--Modal para crear un nuevo edificio -->
                <div id="modal-nvo-edificio" class="modal">
                    <div class="modal-background"></div>
                
                    <div class="modal-content">
                        <div class="box">
                            <p class="title is-5 has-text-centered">Agregar Edificio</p>
                            <form method="POST" action="<?php echo e(route('edificioCreate')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="field">
                                    <div class="control has-icons-left">
                                        <label class="label">Edificio:</label>
                                        <div class="control has-icons-left">
                                            <input class="input" type="text" name = "txtEdificio" value="<?php echo e(old('txtEdificio')); ?>">
                
                                            <span class="icon is-small is-left">
                                                <i class="fa-solid fa-key"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['txtEdificio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="help is-danger">Ingresa el Edificio</p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="field">
                                    <div class="control has-icons-left">
                                        <label class="label">Descripción:</label>
                                        <div class="control has-icons-left">
                                            <input class="input" type="text" name = "txtDescripcion" value="<?php echo e(old('txtDescripcion')); ?>">
                
                                            <span class="icon is-small is-left">
                                                <i class="fa-solid fa-graduation-cap"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['txtDescripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="help is-danger">Ingresa la descripción del edificio</p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>                
                                <div class="has-text-centered">
                                    <button class="button is-primary" type="submit"><i
                                            class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                    <button class="modal-close is-large" aria-label="close"></button>
                </div>
            </div>  
        </div>

        
        <div class="column">
            <div class="box">
                <table class="table is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Salon</th>
                            <th>Edificio</th>
                            <th class="has-text-centered">Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $salones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($salon->nombre_salon); ?></td>
                            <td><?php echo e($salon->edificio->nombre_edificio); ?></td>
                            <td>
                                <div class="field is-grouped has-text-is-centered">
                                    <button class="button is-warning js-modal-trigger" data-target="modal-salon-<?php echo e($salon->id); ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <form action="<?php echo e(route('salonDelete', $salon->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar el salon?')">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                                
                                <div id="modal-salon-<?php echo e($salon->id); ?>" class="modal">
                                    <div class="modal-background"></div>
    
                                    <div class="modal-content">
                                        <div class="box">
                                            <p class="title is-5 has-text-centered">Modificar Salon</p>
                                            <form method="POST" action="<?php echo e(route('salonUpdate', $salon->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <div class="field">
                                                    <label class="label">Nombre de Salon:</label>
                                                    <div class="control">
                                                        <input class="input" type="text" name="txtSalon"
                                                            value="<?php echo e($salon->nombre_salon); ?>">
                                                    </div>
                                                </div>
                                                <div class="field">
                                                    <label class="label">Edificio:</label>
                                                    <div class="control">
                                                        <div class="select">
                                                            <select name="selectEdificios">
                                                                <?php $__currentLoopData = $edificios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edificio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($edificio->id); ?>" <?php echo e($edificio->id == $salon->edificio_id ? 'selected' : ''); ?>><?php echo e($edificio->nombre_edificio); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                          </div>
                                                    </div>
                                                </div>
                                                <div class="has-text-centered">
                                                    <button class="button is-primary" type="submit">Guardar</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
    
                                    <button class="modal-close is-large" aria-label="close"></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody> 
                </table>
        
                <!--Modal para crear un nuevo salon -->
                <div id="modal-nvo-salon" class="modal">
                    <div class="modal-background"></div>
                
                    <div class="modal-content">
                        <div class="box">
                            <p class="title is-5 has-text-centered">Agregar Salon</p>
                            <form method="POST" action="<?php echo e(route('salonCreate')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="field">
                                    <div class="control has-icons-left">
                                        <label class="label">Salon:</label>
                                        <div class="control has-icons-left">
                                            <input class="input" type="text" name = "txtSalon" value="<?php echo e(old('txtSalon')); ?>">
                
                                            <span class="icon is-small is-left">
                                                <i class="fa-solid fa-key"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['txtSalon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="help is-danger">Ingresa el Salon</p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="field">
                                    <div class="control has-icons-left">
                                        <label class="label">Edificio:</label>
                                        <div class="control has-icons-left">
                                            <div class="select">
                                                <select name="selectEdificios">
                                                    <option value="">Seleccionar</option>
                                                    <?php $__currentLoopData = $edificios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edificio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($edificio->id); ?>"><?php echo e($edificio->nombre_edificio); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>                
                                            <span class="icon is-small is-left">
                                                <i class="fa-solid fa-graduation-cap"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['selectEdificios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="help is-danger">Ingresa la descripción del edificio</p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>                
                                <div class="has-text-centered">
                                    <button class="button is-primary" type="submit"><i
                                            class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                                </div>
                            </form>
                        </div>
                    </div>
                    <button class="modal-close is-large" aria-label="close"></button>
                </div>
            </div> 
        </div>
    </div>

    

    <?php if($errors->has('txtEdificio') || $errors->has('txtDescripcion') ): ?>
        <script>
            document.getElementById('modal-edificio').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/escolares/edificio.blade.php ENDPATH**/ ?>