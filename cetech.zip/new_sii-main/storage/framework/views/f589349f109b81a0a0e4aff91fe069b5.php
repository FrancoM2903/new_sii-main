<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Alumnos</p>
        
        <div class="buttons">
            <a href="<?php echo e(route('home')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-alumno">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Alumno
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>No. Control</th>
                    <th>Nombre Completo</th>
                    <th>CURP</th>
                    <th>Semestre</th>
                    <th>Carrera</th>
                    <th>Estatus</th>
                    <th>Tipo de alumno</th>
                    <th class="has-text-centered">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alumno->numero_control); ?></td>
                        <td><?php echo e($alumno->ap_paterno . ' ' . $alumno->ap_materno . ' ' . $alumno->nombre); ?></td>
                        <td><?php echo e($alumno->curp); ?></td>
                        <td><?php echo e($alumno->semestre); ?></td>
                        <td><?php echo e($alumno->planEstudio->carrera); ?></td>
                        <td><?php echo e($alumno->estatus->nombre_estatus); ?></td>
                        <td><?php echo e($alumno->tipoAlumno->nombre_tipo); ?></td>
                        <td> 
                            <div class="field is-grouped">
                                
                                <button class="button is-warning js-modal-trigger" data-target="modal-update-<?php echo e($alumno->id); ?>">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                
                                <form action="<?php echo e(route('alumnoDelete', $alumno->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar al alumno?')">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>

                            
                            <div id="modal-update-<?php echo e($alumno->id); ?>" class="modal">
                                <div class="modal-background"></div>

                                <div class="modal-content">
                                    <div class="box">
                                        <p class="title is-5 has-text-centered">Modificar Alumno</p>
                                        <form method="POST" action="<?php echo e(route('alumnoUpdate', $alumno->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <div class="field">
                                                <label class="label">Número de Control:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtNoControlUp"
                                                        value="<?php echo e($alumno->numero_control); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Nombre:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtNombAlumnUp"
                                                    value="<?php echo e($alumno->nombre); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Apellido Paterno:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtApPatAlumnUp"
                                                    value="<?php echo e($alumno->ap_paterno); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Apellido Materno:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtApMatAlumnUp"
                                                    value="<?php echo e($alumno->ap_materno); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">CURP:</label>
                                                <div class="control">
                                                    <input class="input" type="text" name="txtCURPAlumUp"
                                                    value="<?php echo e($alumno->curp); ?>" maxlength="18">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Semestre:</label>
                                                <div class="control">
                                                    <input class="input" type="number" name="txtSemestreUp"
                                                    value="<?php echo e($alumno->semestre); ?>">
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Carrera:</label>
                                                <div class="control">
                                                    <div class="select">
                                                        <select name="selectCarreraAlumUp">
                                                            <?php $__currentLoopData = $plan_estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan_estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($plan_estudio->id); ?>" 
                                                                    <?php echo e($plan_estudio->id == $alumno->plan_estudio_id ? 'selected' : ''); ?> >
                                                                    <?php echo e($plan_estudio->carrera); ?> 
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                      </div>
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Estatus:</label>
                                                <div class="control">
                                                    <div class="select">
                                                        <select name="selectEsatAlumUp">
                                                            <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($status->id); ?>" 
                                                                    <?php echo e($status->id == $alumno->estatus_id ? 'selected' : ''); ?> >
                                                                    <?php echo e($status->nombre_estatus); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                      </div>
                                                </div>
                                            </div>
                                            <div class="field">
                                                <label class="label">Tipo de alumno:</label>
                                                <div class="control">
                                                    <div class="select">
                                                        <select name="selectTipoAlumUp">
                                                            <?php $__currentLoopData = $tipos_alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tipo_alumno->id); ?>" <?php echo e($tipo_alumno->id == $alumno->tipo_alumno_id ? 'selected' : ''); ?>><?php echo e($tipo_alumno->nombre_tipo); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                      </div>
                                                </div>
                                            </div>
                                            <div class="has-text-centered">
                                                <button class="button is-primary" type="submit">Guardar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <button class="modal-close is-large" aria-label="close"></button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!--Modal para crear alumnos -->
        <div id="modal-nvo-alumno" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar alumno</p>
                    <form method="POST" action="<?php echo e(route('alumnoCreate')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Número de Control:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtNoControl" 
                                        value="<?php echo e(old('txtNoControl')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-key"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtNoControl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el Número de control</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Nombre:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtNombAlumn" 
                                        value="<?php echo e(old('txtNombAlumn')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtNombAlumn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el nombre del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Apellido Paterno:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtApPatAlumn" 
                                        value="<?php echo e(old('txtApPatAlumn')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtApPatAlumn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el apellido del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Apellido Materno:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtApMatAlumn"
                                        value="<?php echo e(old('txtApMatAlumn')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtApMatAlumn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el apellido del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">CURP:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtCURPAlum"
                                        value="<?php echo e(old('txtCURPAlum')); ?>" maxlength="18">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtCURPAlum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el CURP del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Semestre:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="number" name = "txtSemestre"
                                        value="<?php echo e(old('txtSemestre')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtSemestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el semestre del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Carrera:</label>
                                <div class="control has-icons-left">
                                    <div class="select">
                                        <select name="selectCarreraAlum">
                                            <option value="">Seleccionar</option>
                                            <?php $__currentLoopData = $plan_estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan_estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($plan_estudio->id); ?>" >
                                                    <?php echo e($plan_estudio->carrera); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['selectCarreraAlum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la carrera del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Estatus:</label>
                                <div class="control has-icons-left">
                                    <div class="select">
                                        <select name="selectEsatAlum">
                                            <option value="">Seleccionar</option>
                                            <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->id); ?>" >
                                                    <?php echo e($status->nombre_estatus); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['selectEsatAlum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el estatus del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Tipo de alumno:</label>
                                <div class="control has-icons-left">
                                    <div class="select">
                                        <select name="selectTipoAlum">
                                            <option value="">Seleccionar</option>
                                            <?php $__currentLoopData = $tipos_alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tipo_alumno->id); ?>" >
                                                    <?php echo e($tipo_alumno->nombre_tipo); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['selectTipoAlum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el estatus del alumno</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>  
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
        
            <button class="modal-close is-large" aria-label="close"></button>
        </div>



    </div>

    <?php if($errors->has('txtClave') || $errors->has('txtCarrera') ): ?>
        <script>
            document.getElementById('modal-nvo-plan').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/escolares/alumno.blade.php ENDPATH**/ ?>