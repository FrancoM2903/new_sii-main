<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Alumnos inscritos en <?php echo e($grupo->semestre); ?><?php echo e($grupo->letra_grupo); ?></p>
        
        <div class="buttons">
            <a href="<?php echo e(route('escolaresPlanesEstudio')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-alumno-gr">
                <i class="fa-solid fa-plus"></i>&nbsp;Nueva Materia
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>No. Control</th>
                    <th>Nombre Completo</th>
                    <th>Semestre</th>
                    <th class="has-text-centered">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $grupo->alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($alumnos->numero_control); ?></td>
                        <td><?php echo e($alumnos->ap_paterno); ?> <?php echo e($alumnos->ap_materno); ?> <?php echo e($alumnos->nombre); ?></td>
                        <td><?php echo e($alumnos->semestre); ?></td>
                        <td> 
                            <div class="field is-grouped has-text-centered">
                                
                                <form action="<?php echo e(route('alumnoGrupoDelete', [$grupo->id, $alumnos->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar la materia?')">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!--Modal para crear alumnos -->
       <div id="modal-nvo-alumno-gr" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar Alumno</p>
                    <form method="POST" action="<?php echo e(route('alumnoGrupoCreate', $grupo->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Alumnos:</label>
                                <div class="control has-icons-left">
                                    <div class="select">
                                        <select name="selectAlumGru">
                                            <option value="">Seleccionar</option>
                                            <?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($alumnos->id); ?>">
                                                    <?php echo e($alumnos->ap_paterno); ?> <?php echo e($alumnos->ap_materno); ?> <?php echo e($alumnos->nombre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['selectAlumGru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la descripción del edificio</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>     
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
            <button class="modal-close is-large" aria-label="close"></button>
        </div>



    </div>

    <?php if($errors->has('txtClave') || $errors->has('txtCarrera') ): ?>
        <script>
            document.getElementById('modal-nvo-plan').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/divEstudio/alumno-grupo.blade.php ENDPATH**/ ?>