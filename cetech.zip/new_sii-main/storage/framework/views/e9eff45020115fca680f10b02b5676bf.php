<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Materias Inscritas</p>
        
        <div class="buttons">
            <a href="#" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>Periodo</th>
                    <th>Plan</th>
                    <th>Materia</th>
                    <th>Grupo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumno->grupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($grupo->periodo->estatus == 'En curso'): ?>
                        <tr>
                            <td><?php echo e($grupo->periodo->clave_periodo.' '.$grupo->periodo->nombre_periodo); ?></td>
                            <td><?php echo e($grupo->planEstudio->carrera); ?></td>
                            <td><?php echo e($grupo->materia->nombre); ?></td>
                            <td><?php echo e($grupo->semestre.$grupo->letra_grupo); ?></td>
                        </tr>
                    <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/alumno/lista-grupo-alumno.blade.php ENDPATH**/ ?>