<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Planes de Estudio y Especialiadades</p>
        
        <div class="buttons">
            <a href="<?php echo e(route('home')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nvo-plan">
                <i class="fa-solid fa-plus"></i>&nbsp;Nuevo Plan
            </a>
            <a class="button is-primary js-modal-trigger" data-target="modal-nva-especialidad">
                <i class="fa-solid fa-plus"></i>&nbsp;Nueva Especialidad
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <div class="columns">
            <div class="column">
                <div class="box">
                    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
                        <thead>
                            <tr>
                                <th>Plan de Estudio</th>
                                <th>Carrera</th>
                                <th class="has-text-centered">Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->clave_plan_estudio); ?></td>
                                    <td><?php echo e($item->carrera); ?></td>
                                    <td>
                                        <div class="field is-grouped">
                                            <?php if (\Illuminate\Support\Facades\Blade::check('hasrole', 'escolares')): ?>
                                                <button class="button is-warning js-modal-trigger" data-target="modal-<?php echo e($item->id); ?>">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </button>
                                                <form action="<?php echo e(route('PlanesEstudioEliminar', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="button is-danger" onclick="return confirm('¿Estás seguro de que quieres eliminar este plan de estudios?')">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <form action="<?php echo e(route('escolaresMateriaPlanEstudio', $item->id)); ?>" method="GET">
                                                <button type="submit" class="button is-info" title="Ver Materias">
                                                    <i class="fa-solid fa-book"></i>
                                                </button>
                                            </form>
                                            <form action="<?php echo e(route('escolaresGrupo', $item->id)); ?>" method="GET">
                                                <button type="submit" class="button is-info" title="Ver Grupos">
                                                    <i class="fa-solid fa-people-roof"></i>
                                                </button>
                                            </form>
                                        </div>
            
                                        <div id="modal-<?php echo e($item->id); ?>" class="modal">
                                            <div class="modal-background"></div>
            
                                            <div class="modal-content">
                                                <div class="box">
                                                    <p class="title is-5 has-text-centered">Modificar Plan de Estudio</p>
                                                    <form method="POST" action="<?php echo e(route('planEstudioUpdate', $item->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <div class="field">
                                                            <label class="label">Clave del Plan de Estudios:</label>
                                                            <div class="control">
                                                                <input class="input" type="text" name="txtClave"
                                                                    value="<?php echo e($item->clave_plan_estudio); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="field">
                                                            <label class="label">Nombre de la carrera:</label>
                                                            <div class="control">
                                                                <input class="input" type="text" name="txtCarrera"
                                                                value="<?php echo e($item->carrera); ?>">
                                                            </div>
                                                        </div>
            
                                                        <div class="has-text-centered">
                                                            <button class="button is-primary" type="submit">Guardar</a>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
            
                                            <button class="modal-close is-large" aria-label="close"></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table> 
                </div> 
            </div> 

            <div class="column">
                <div class="box">
                    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
                        <thead>
                            <tr>
                                <th>Clave de Especiaidad</th>
                                <th>Nombre de Especialidad</th>
                                <th>Plan de Estudio de la Especialidad</th>
                                <th class="has-text-centered">Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($especialidad->clave_especialidad); ?></td>
                                    <td><?php echo e($especialidad->especilidad); ?></td>
                                    <td><?php echo e($especialidad->planEstudio->carrera); ?></td>
                                    <td>
                                        <div class="field is-grouped">
                                            <button class="button is-warning js-modal-trigger" data-target="modal-up-especialidad-<?php echo e($especialidad->id); ?>">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>
                                            <form action="<?php echo e(route('especialidadDelete', $especialidad->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="button is-danger"  onclick="return confirm('¿Estás seguro de que quieres eliminar esta especialidad?')">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        </div>

                                        
                                        <div id="modal-up-especialidad-<?php echo e($especialidad->id); ?>" class="modal">
                                            <div class="modal-background"></div>
                                            <div class="modal-content">
                                                <div class="box">
                                                    <p class="title is-5 has-text-centered">Modificar Especialidad</p>
                                                    <form method="POST" action="<?php echo e(route('especialidadUpdate', $especialidad->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <div class="field">
                                                            <label class="label">Clave de la Especialidad:</label>
                                                            <div class="control">
                                                                <input class="input" type="text" name="txtClaveEsp_Up"
                                                                    value="<?php echo e($especialidad->clave_especialidad); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="field">
                                                            <label class="label">Nombre de la Especialidad:</label>
                                                            <div class="control">
                                                                <input class="input" type="text" name="txtEspecialidad_Up"
                                                                value="<?php echo e($especialidad->especilidad); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="field">
                                                            <label class="label">Edificio:</label>
                                                            <div class="control">
                                                                <div class="select">
                                                                    <select name="selectPlanEsp_Up">
                                                                        <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($plan->id); ?>" <?php echo e($plan->id == $especialidad->plan_estudio_id ? 'selected' : ''); ?>><?php echo e($plan->carrera); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                  </div>
                                                            </div>
                                                        </div>
                                                        <div class="has-text-centered">
                                                            <button class="button is-primary" type="submit">Guardar</a>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <button class="modal-close is-large" aria-label="close"></button>
                                        </div> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table> 
                </div> 

            </div> 

        </div> 



        <!--Modal para crear un nuevo plan -->
        <div id="modal-nvo-plan" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar Plan de Estudio</p>
                    <form method="POST" action="<?php echo e(route('PlanesEstudioCrear')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Clave del Plan de Estudios:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtClave" value="<?php echo e(old('txtClave')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-key"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtClave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la clave del plan de estudios</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Nombre de la carrera:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtCarrera"
                                        value="<?php echo e(old('txtCarrera')); ?>">
        
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtCarrera'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el nombre de la carrera</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
        
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
        
            <button class="modal-close is-large" aria-label="close"></button>
        </div>

        <!--Modal para crear un nuevo especialidad -->
        <div id="modal-nva-especialidad" class="modal">
            <div class="modal-background"></div>
        
            <div class="modal-content">
                <div class="box">
                    <p class="title is-5 has-text-centered">Agregar Especialidad:</p>
                    <form method="POST" action="<?php echo e(route('especialidadCreate')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Clave de la Especialidad:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtClaveEsp" value="<?php echo e(old('txtClaveEsp')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-key"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtClaveEsp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la clave de la especialidad</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Nombre de la Especialidad:</label>
                                <div class="control has-icons-left">
                                    <input class="input" type="text" name = "txtEspecialidad" value="<?php echo e(old('txtEspecialidad')); ?>">
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['txtEspecialidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa el nombre de la especialidad</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field">
                            <div class="control has-icons-left">
                                <label class="label">Edificio:</label>
                                <div class="control has-icons-left">
                                    <div class="select">
                                        <select name="selectPlanEsp">
                                            <option value="">Seleccionar</option>
                                            <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->carrera); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                
                                    <span class="icon is-small is-left">
                                        <i class="fa-solid fa-graduation-cap"></i>
                                    </span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['selectPlanEsp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger">Ingresa la descripción del edificio</p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="has-text-centered">
                            <button class="button is-primary" type="submit"><i
                                    class="fa-solid fa-floppy-disk"></i>&nbsp;Guardar</a>
                        </div>
                    </form>
                </div>
            </div>
        
            <button class="modal-close is-large" aria-label="close"></button>
        </div>



    </div>

    <?php if($errors->has('txtClave') || $errors->has('txtCarrera') ): ?>
        <script>
            document.getElementById('modal-nvo-plan').classList.add('is-active');
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/escolares/planes-estudio.blade.php ENDPATH**/ ?>