<?php $__env->startSection('content'); ?>
    <div class="box">
        <p class="title is-3 has-text-centered">Lista de Alumnos</p>
        <p class="title is-5 has-text-centered">Grupos asignados</p>
        
        <div class="buttons">
            <a href="<?php echo e(route('escolaresPlanesEstudio')); ?>" class="button is-danger">
                <i class="fa-solid fa-arrow-left"></i>&nbsp;Regresar
            </a>
        </div>

        <?php if(session('Correcto')): ?>
            <div class="notification is-success">
                <button class="delete"></button>
                <?php echo e(session('Correcto')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('Incorrecto')): ?>
            <div class="notification is-danger">
                <button class="delete"></button>
                <?php echo e(session('Incorrecto')); ?>

            </div>
        <?php endif; ?>

        <table class="table is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>Periodo</th>
                    <th>Plan Estudio</th>
                    <th>Materia</th>
                    <th>Grupo</th>
                    <th class="has-text-centered">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $docente->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($grupo->periodo->nombre_periodo); ?></td>
                        <td><?php echo e($grupo->planEstudio->carrera); ?></td>
                        <td><?php echo e($grupo->materia->nombre); ?></td>
                        <td><?php echo e($grupo->semestre.$grupo->letra_grupo); ?></td>
                        <td> 
                            <div class="field is-grouped has-text-centered">
                                <form action="<?php echo e(route('docenteGruposDocenteAlumno', $docente->id)); ?>#" method="GET">
                                    <button type="submit" class="button is-info" title="Listas">
                                        <i class="fa-solid fa-list"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\josue\Documents\PROGRA WEB\cetech\new_sii-main\new_sii-main\resources\views/docente/lista-grupo-docente.blade.php ENDPATH**/ ?>